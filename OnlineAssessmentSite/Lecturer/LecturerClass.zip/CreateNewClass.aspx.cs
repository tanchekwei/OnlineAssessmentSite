﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace OnlineAssessmentSite.Lecturer
{
    public partial class CreateClass : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        public void fvClass_InsertItem()
        {
            Models.Class item = new Models.Class();

            MembershipUser user = Membership.GetUser(User.Identity.Name);
            Guid guid = (Guid)user.ProviderUserKey;

            item.UserId = guid;

            TryUpdateModel(item);
            if (ModelState.IsValid)
            {
                // Save changes here
                OnlineAssessmentSite.Models.OnlineAssessmentSiteEntities _db
                    = new OnlineAssessmentSite.Models.OnlineAssessmentSiteEntities();
                _db.Classes.Add(item);
                _db.SaveChanges();
                Response.Redirect("/Lecturer/AddStudentToClass.aspx");
            }
        }
    }
}