﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace OnlineAssessmentSite.Lecturer
{
    public partial class MaintainClass : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //Debug.WriteLine("Roles.IsUserInRole(lecturer) = " + Roles.IsUserInRole("lecturer"));
            //Debug.WriteLine("Roles.IsUserInRole(student) = " + Roles.IsUserInRole("student"));
            //Debug.WriteLine("Roles.IsUserInRole(admin) = " + Roles.IsUserInRole("admin"));

            if (Roles.IsUserInRole("lecturer") || Roles.IsUserInRole("admin"))
            {
                MembershipUser user = Membership.GetUser(User.Identity.Name);
                Guid guid = (Guid)user.ProviderUserKey;
                SqlDataSource1.SelectParameters["UserId"].DefaultValue = guid.ToString();

                // TODO: Display student in the class


            }
            else
            {
                Response.Write("<script language=javascript>alert('Don\\'t force yourself to fit in where you don\\'t belong.');" +
                    "window.location.href = \"../Login.aspx\";</script>");
            }
        }


        //protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        //{
        //    if (e.CommandName == "Add Student")
        //    {
        //        HttpCookie cookie = new HttpCookie("AddStudent");

        //        // Convert the row index stored in the CommandArgument
        //        // property to an Integer.
        //        int index = Convert.ToInt32(e.CommandArgument);
        //        GridViewRow selectedRow = GridView1.Rows[index];

        //        cookie["classID"] = selectedRow.Cells[2].Text;
        //        cookie["className"] = selectedRow.Cells[4].Text;
        //        Response.Write(selectedRow.Cells[2].Text);
        //        // Add it to the current web response.
        //        Response.Cookies.Add(cookie);
        //        Response.Redirect("/Lecturer/AddStudentToClass.aspx");
        //    }
        //}
    }
}